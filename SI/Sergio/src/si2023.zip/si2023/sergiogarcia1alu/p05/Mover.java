package si2023.sergiogarcia1alu.p05;

import si2023.sergiogarcia1alu.strips.Operador;
import si2023.sergiogarcia1alu.strips.Meta;
import si2023.sergiogarcia1alu.strips.StripsState;

import java.util.ArrayList;

public class Mover extends Operador {
    @Override
    public ArrayList<Operador> gen_posibilidades(Meta m, StripsState estado_actual) {
        return null;
    }

    @Override
    public Operador clone() {
        return null;
    }
}
