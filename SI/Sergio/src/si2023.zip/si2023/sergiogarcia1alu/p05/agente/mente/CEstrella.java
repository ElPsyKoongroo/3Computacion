package si2023.sergiogarcia1alu.p05.agente.mente;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

import ontology.Types.ACTIONS;
import si2023.sergiogarcia1alu.p05.agente.nodo.Estado;
import si2023.sergiogarcia1alu.shared.Mundo16;
import tools.Vector2d;

// Todos sabemos que C es mejor lenguaje que A y que B
public class CEstrella {

    class Pair {
        private final double X;
        private final double Y;

        Pair(double x, double y) {
            this.X = x;
            this.Y = y;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null)
                return false;
            if (this.getClass() != o.getClass())
                return false;
            Pair other = (Pair) o;
            return this.X == other.X && this.Y == other.Y;
        }

        @Override
        public int hashCode() {
            return (int) (this.X * 100 + this.Y);
        }
    }

    private final Map<Vector2d, ACTIONS> traductor = new HashMap<Vector2d, ACTIONS>();

    public CEstrella(Mundo16 mundo) {
        traductor.put(Estado.DOWN, ACTIONS.ACTION_DOWN);
        traductor.put(Estado.UP, ACTIONS.ACTION_UP);
        traductor.put(Estado.RIGHT, ACTIONS.ACTION_RIGHT);
        traductor.put(Estado.LEFT, ACTIONS.ACTION_LEFT);
    }

    private Stack<ACTIONS> get_camino(Estado e) {
        Stack<ACTIONS> acciones = new Stack<>();
        while (e.parent != null) {
            acciones.add(this.traductor.get(e.accion));
            e = e.parent;
        }
        return acciones;
    }

    private Pair make_pair(Vector2d pos) {
        return new Pair(pos.x, pos.y);
    }

    public Stack<ACTIONS> Busqueda(Estado inicial, Vector2d fin) {
        Queue<Estado> abiertos = new ArrayDeque<>();
        Set<Pair> cerrados = new HashSet<>();
        ArrayList<Stack<ACTIONS>> rutas = new ArrayList<>();

        abiertos.add(inicial);
        cerrados.add(this.make_pair(inicial.get_player_pos()));
        while (!abiertos.isEmpty()) {
            Estado estado_actual = abiertos.poll();
            // System.out.println("Abiertos: " + abiertos.size());

            if (estado_actual.get_player_pos().equals(fin)) {
                // TODO!

                rutas.add(this.get_camino(estado_actual));
            } else {

                cerrados.add(this.make_pair(estado_actual.get_player_pos()));
                ArrayList<Estado> sucesores = estado_actual.genera_sucesores();
                for (Estado s : sucesores) {
                    Pair x = this.make_pair(s.get_player_pos());
                    if (!cerrados.contains(x)) {
                        abiertos.add(s);
                        if (s.get_player_pos().equals(fin)) {
//                          System.out.println("Ignorando meta");
                        } else {
                            cerrados.add(x);
                        }
                    }
                }
            }
        }
        System.out.println("Rutas: " + rutas.size());
        return rutas.get(0);
    }
}
