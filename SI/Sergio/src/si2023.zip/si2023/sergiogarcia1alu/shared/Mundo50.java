package si2023.sergiogarcia1alu.shared;

import java.util.ArrayList;

import core.game.Observation;
import core.game.StateObservation;
import si2023.sergiogarcia1alu.ia.mente.Mundo;
import tools.Vector2d;

public class Mundo50 implements Mundo {
    
    public enum iType {
        Player,
        Tree,
        Goal,
        Oligo,
        Nothing
    }

    public static final int JUGADOR = 9;

    private int block_size;
    private iType[][] grid;
    private final ArrayList<Observation>[][] map;
    private boolean mundo_ok;
    private iType goal_type = iType.Goal;
    private Vector2d player_position;

    /// Copy constructor mejor que clone.
    /// see:
    /// https://www.doc-developpement-durable.org/file/Projets-informatiques/cours-&-manuels-informatiques/java/Effective%20Java,%202nd%20Edition.pdf
    public Mundo50(Mundo50 other) {
        this.map = other.map;
        if (other.player_position == null || other.grid == null) {
            this.mundo_ok = false;
            return;
        }

        this.mundo_ok = true;
        this.player_position = other.player_position.copy();
        this.block_size = other.block_size;
        this.grid = new iType[other.grid.length][other.grid.length];
        for (int i = 0; i < other.grid.length; i++) {
            for (int j = 0; j < other.grid[i].length; ++j) {
                this.grid[i][j] = other.grid[i][j];
            }
        }
    }

    public Mundo50(StateObservation state) {
        this.map = state.getObservationGrid().clone();
        this.grid = new iType[state.getObservationGrid().length][state.getObservationGrid()[0].length];
        this.actualizar(state);
    }

    // Esto tiene un Bug
    private void set_grid(StateObservation m) {
        ArrayList<Observation>[][] estados = m.getObservationGrid();
        for (int i = 0; i < this.grid.length; i++) {
            for (int j = 0; j < this.grid[i].length; j++) {
                if (estados[i][j].size() == 0) {
                    grid[i][j] = iType.Nothing;
                } else {
                    for (Observation o : estados[i][j]) {
                        this.set_type(i, j, o.itype);
                    }
                }
            }
        }
    }

    private iType get_type(int type) {
        // Mirar esquema de arriba
        switch (type) {
            case 0:
                return iType.Tree;
            case 3:
                return iType.Oligo;
            case 1:
                return iType.Player;
            case 4:
                return iType.Goal;
            default:
                return iType.Nothing;
        }
    }

    public iType get_pos_type(int x, int y) {
        return this.grid[x][y];
    }

    public boolean is_andable(iType t) {
        switch (t) {
            case Nothing:
                return true;
            case Goal:
                return true;
            default:
                return false;
        }
    }

    public ArrayList<Vector2d> get_pos_iType(iType tipo) {
        ArrayList<Vector2d> pos = new ArrayList<>();
        for (int x = this.grid.length - 1; x >= 0; x--) {
            for (int y = this.grid[x].length - 1; y >= 0; y--) {
                if (this.grid[x][y] == tipo) {
                    pos.add(new Vector2d(x, y));
                }
            }
        }
        return pos;
    }

    public Vector2d get_player_pos_block() {
        return new Vector2d(this.player_position.x / this.get_block_size(),
                this.player_position.y / this.get_block_size());
    }

    public int get_block_size() {
        return this.block_size;
    }

    public boolean is_in_range(Vector2d pos) {
        return !((pos.x < 0 || pos.x > this.grid.length)
                || (pos.y < 0 || pos.y > this.grid[0].length));
    }

    private void set_type(int x, int y, int type) {
        this.grid[x][y] = get_type(type);
    }

    public boolean is_goal(Vector2d pos) {
        return this.get_pos_type(pos) == iType.Goal;
    }

    public iType get_pos_type(Vector2d pos) {
        return this.grid[(int) pos.x][(int) pos.y];
    }

    @Override
    public void actualizar(StateObservation mundo) {
        this.set_grid(mundo);
        this.block_size = mundo.getBlockSize();
        this.player_position = mundo.getAvatarPosition();
    }
}
