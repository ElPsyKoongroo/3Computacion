package si2023.sergiogarcia1alu.shared;

import java.util.ArrayList;

import core.game.Observation;
import core.game.StateObservation;
import si2023.sergiogarcia1alu.ia.mente.Mundo;
import tools.Vector2d;

public class Mundo16 implements Mundo {
	public static enum iType {
		Player, 
        Water,
        Tree,
        Right,
        Down,
        Left,
        Up,
        Goal,
        Nothing,
        Invalid
	}

	public static final int JUGADOR = 9;

	private int block_size;
	private iType[][] grid;
	private final ArrayList<Observation>[][] map;
	private boolean mundo_ok;
	private Vector2d player_position;

	/// Copy constructor mejor que clone.
	/// see:
	/// https://www.doc-developpement-durable.org/file/Projets-informatiques/cours-&-manuels-informatiques/java/Effective%20Java,%202nd%20Edition.pdf
	public Mundo16(Mundo16 other) {
		this.map = other.map;
		if (other.player_position == null || other.grid == null) {
			this.mundo_ok = false;
			return;
		}

		this.mundo_ok = true;
		this.player_position = other.player_position.copy();
		this.block_size = other.block_size;
		this.grid = new iType[other.grid.length][other.grid.length];
		for(int i = 0; i< other.grid.length; i++) {
		    for(int j = 0; j<other.grid[i].length; ++j) {
		        this.grid[i][j] = other.grid[i][j];
		    }
		}
	}

	public Mundo16(StateObservation state) {
		this.map = state.getObservationGrid().clone();
		this.grid = new iType[state.getObservationGrid().length][state.getObservationGrid()[0].length];
		this.actualizar(state);
	}

	private iType get_type(int type) {
		// Mirar esquema de arriba
	    switch (type) {
	        case 0: return iType.Tree;
	        case 9: return iType.Player;
	        case 7: return iType.Right;
	        case 5: return iType.Down;
	        case 15: return iType.Goal;
	        case 3: return iType.Water;
	        case 8: return iType.Left;
	        case 6: return iType.Up;
	        default: return iType.Nothing;
	    }
	}	

	
	public boolean is_andable(iType type) {
		// Mirar esquema de arriba
	    switch (type) {
	        case Tree: return false;
	        case Player: return false;
	        case Right: return true;
	        case Down: return true;
	        case Left: return true;
	        case Up: return true;
	        case Goal: return true;
	        case Water: return false;
	        case Nothing: return true;
	        case Invalid: return false;
	    }
        return false;
	}	
	
	public boolean is_movimiento(iType type) {
	    switch (type) {
	    case Right:
	    case Up:
	    case Left:
	    case Down: return true;
	    default: return false;
	    }
	}
	
	public boolean is_hostiable(iType t) {
	    if (t == iType.Tree) return true;
	    if (t == iType.Invalid) {
	        return true;
	    }
	    return false;
	}
	
	// Esto tiene un Bug
	private void set_grid(StateObservation m) {
		ArrayList<Observation>[][] estados = m.getObservationGrid();
		for (int i = 0; i < this.grid.length; i++) {
			for (int j = 0; j < this.grid[i].length; j++) {
				if (estados[i][j].size() == 0) {
					grid[i][j] = iType.Nothing;
				} else {
					for (Observation o : estados[i][j]) {
						this.set_type(i, j, o.itype);
					}
				}
			}
		}
	}

	private void set_type(int x, int y, int type) {
		this.grid[x][y] = get_type(type);
	}

	@Override
	public void actualizar(StateObservation mundo) {
		this.set_grid(mundo);
		this.block_size = mundo.getBlockSize();
		this.player_position = mundo.getAvatarPosition();
	}

	public int get_block_size() {
		return this.block_size;
	}

	public int[] get_dimensions() {
		return new int[] { this.grid.length, this.grid[0].length };
	}

    public iType[][] get_grid() {
		return this.grid;
	}

	public ArrayList<Observation> get_obs_iType(iType tipo) {
		ArrayList<Observation> pos = new ArrayList<>();
		for (int x = this.grid.length - 1; x > 0; x--) {
			for (int y = this.grid[x].length - 1; y > 0; y--) {
				for (Observation o : this.map[x][y]) {
					if (this.get_type(o.itype) == tipo) {
						pos.add(o);
					}
				}
			}
		}
		return pos;
	}

	public Vector2d get_player_position() {
		return this.player_position;
	}

	public ArrayList<Vector2d> get_pos_iType(iType tipo) {
		ArrayList<Vector2d> pos = new ArrayList<>();
		for (int x = this.grid.length - 1; x >= 0; x--) {
			for (int y = this.grid[x].length - 1; y >= 0; y--) {
				if (this.grid[x][y] == tipo) {
					pos.add(new Vector2d(x, y));
				}
			}
		}
		return pos;
	}

	// Triquiñuela, pero no voy a poner la ñ por motivos logicos
	public Mundo16 triquinuela(Vector2d pos, iType t) {
	    Mundo16 other = new Mundo16(this);
	    other.grid[(int) pos.x][(int) pos.y] = t;
	    return other;
	}
	
	public iType get_pos_type(int x, int y) {
		return this.grid[x][y];
	}
	
	public boolean is_in_range(Vector2d pos) {
	    return !((pos.x < 0 || pos.x > 15) || (pos.y < 0 || pos.y > 15));
	}
	
	public boolean is_goal(Vector2d pos) {
	    return this.get_pos_type(pos) == iType.Goal;
	}
	
	public iType get_pos_type(Vector2d pos) {
	    return this.grid[(int) pos.x][(int) pos.y];
	}

	public ArrayList<Observation> map_pos(int x, int y) {
		return this.map[x][y];
	}

	public Vector2d get_player_pos_block() {
		return new Vector2d(this.player_position.x / this.get_block_size(), this.player_position.y / this.get_block_size());
	}

	public boolean ok() {
		return this.mundo_ok;
	}
}
