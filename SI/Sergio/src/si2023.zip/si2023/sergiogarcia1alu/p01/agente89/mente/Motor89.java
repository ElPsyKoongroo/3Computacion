package si2023.sergiogarcia1alu.p01.agente89.mente;

import java.util.ArrayList;

import core.game.StateObservation;
import ontology.Types.ACTIONS;
import si2023.sergiogarcia1alu.ia.mente.Motor;
import si2023.sergiogarcia1alu.ia.mente.Mundo;
import si2023.sergiogarcia1alu.ia.reglas.Regla;
import si2023.sergiogarcia1alu.p01.agente89.reglas.CapturarEnemigo;
import si2023.sergiogarcia1alu.p01.agente89.reglas.Default;
import si2023.sergiogarcia1alu.p01.agente89.reglas.ParguelaPeligroso;
import si2023.sergiogarcia1alu.p01.agente89.reglas.SalirCarcel;
import si2023.sergiogarcia1alu.p01.agente89.reglas.SalvarParguela;
import si2023.sergiogarcia1alu.p01.agente89.reglas.VaciarBolsa;
import si2023.sergiogarcia1alu.shared.Mundo89;


public class Motor89 implements Motor {

	private Mundo89 mundo;
	private ArrayList<Regla> reglas;

	public Motor89(StateObservation mundo) {
		this.mundo = new Mundo89(mundo);
		this.reglas = new ArrayList<>();
		this.reglas.add(new ParguelaPeligroso());
		this.reglas.add(new SalvarParguela());
//		this.reglas.add(new PrevieneParguela());  // No parece afectar en mucho al WinRate 
		this.reglas.add(new VaciarBolsa());
		this.reglas.add(new SalirCarcel());
		this.reglas.add(new CapturarEnemigo());
		this.reglas.add(new Default());
	}

	@Override
	public ACTIONS decide(Mundo m) {
		for(Regla r: this.reglas) { 
			if (r.se_cumple(m)) {
				return r.act().do_action(m);
			}
		}
		System.out.println("No se cumple nada");
		return ACTIONS.ACTION_NIL;
	}

	@Override
	public ACTIONS pensar(Mundo m) {
		Mundo89 mundo = (Mundo89) m;
		this.mundo = new Mundo89(mundo);

		// En modo grafico el juego tarda en iniciarse
		// por lo que es necesaria esta comprobacion para
		// que no pete.
		if (this.mundo.ok())
			return this.decide(m);

		System.out.println("Mapa no ok");
		return ACTIONS.ACTION_NIL;

	}
	
}
