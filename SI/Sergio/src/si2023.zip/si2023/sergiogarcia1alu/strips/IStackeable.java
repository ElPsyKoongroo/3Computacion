package si2023.sergiogarcia1alu.strips;

public interface IStackeable {
    boolean is_accion();
    IStackeable clone();
}
