

Cositas de la practica:

    Todo es exactamente igual que la practica anterior:

        Me referire como Parguelas a los Civiles.

        1. 	El algoritmo tiene una media del 90% de Winrate con las reglas que tiene ahora mismo.
            Se podria conseguir un WinRate del 100% pero a cambio dejariamos de obtener la maxima
            puntuancion (4049). El planteamiento actual es intentar rescatar a todos los Parguelas
            para obtener 1 punto por cada uno, y despues capturar a los malos.
            
            Se podria cambiar el planteamiento para no dejara caer a los parguela y mientras no haya
            ninguno cayendo que vaya a capturar enemigos. Asi obtendriamos el 100% de winrate.
            (Mirar HayEnemigo.java)
            
        2. 	He intentado comentar las cosas mas "chungas" de la practica para que no haga falta
            hacer un seguimiento del algoritmo para entender lo que hace. Tambien he intentado
            reducir la cantidad de magic numbers lo maximo posible.
            
        3.	No tomar en serio los nombres de las variables. (Probablemente el punto mas importante)


   	Además: 
   		He refactorizado un poco los métodos de las otras practicas de las clases abstractas para 
   		que tengan todas el mismo nombre y el cambio de una mente a otra sea más trivial. 
   		
   		He pasado Mundo89 a shared para que java no se queje porque la verdad es un poco tonto el 
   		niño.
   		
   		Como siempre perdon por los nombres de las variables, me he tomado libertades a la hora
   		de diseñar las clases y como ponerlas y el WR al 90%.
   		
   		En la practica 4 el WR se queda en 87% debido a que protege parguela está activado, si se
   		desactiva vuelve a 90%.
   		
   		
   		
   		