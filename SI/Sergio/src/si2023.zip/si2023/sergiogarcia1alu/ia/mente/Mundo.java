package si2023.sergiogarcia1alu.ia.mente;

import core.game.StateObservation;

public interface Mundo {    
	void actualizar(StateObservation state);
}
