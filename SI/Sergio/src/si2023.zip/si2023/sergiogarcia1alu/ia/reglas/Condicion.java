package si2023.sergiogarcia1alu.ia.reglas;
import si2023.sergiogarcia1alu.ia.mente.Mundo;

public interface Condicion {
	boolean se_cumple(Mundo m);
}
