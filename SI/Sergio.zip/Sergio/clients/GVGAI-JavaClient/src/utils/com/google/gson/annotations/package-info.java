/**
 * This package provides annotations that can be used with {@link utils.com.google.gson.Gson}.
 * 
 * @author Inderjeet Singh, Joel Leitch
 */
package utils.com.google.gson.annotations;